import parser from '../src'
import { generatePlaylist } from './helpers/generate-playlist'

// Scale/load guard: 50k channels with a realistic mix of long JWT URLs,
// pipe options, #EXTVLCOPT lines, comments, and radio entries. Catches
// correctness-at-scale regressions (item loss, index drift) and gross
// performance regressions: an accidental O(n²) would blow far past the
// wall-clock guard (the optimized parser needs ~150 ms here; the guard
// is 20x that to stay robust on slow CI runners).
const COUNT = 50000

it(`parses ${COUNT} channels completely and in order`, () => {
  const playlist = generatePlaylist(COUNT)

  const started = Date.now()
  const result = parser.parse(playlist)
  const elapsed = Date.now() - started

  expect(result.items.length).toBe(COUNT)
  expect(result.header.attrs['x-tvg-url']).toBe('https://epg.example/guide.xml')

  // every item resolved a URL, in generation order
  for (let i = 0; i < COUNT; i++) {
    const item = result.items[i]
    if (item.name !== `Channel ${i}` || item.url === undefined) {
      // fail with context instead of 50k silent assertions
      throw new Error(
        `item ${i} broken: name=${JSON.stringify(item.name)} url=${JSON.stringify(item.url)}`
      )
    }
  }

  // spot-check the three URL shapes
  expect(result.items[1].url.length).toBeGreaterThan(2084) // long JWT
  expect(result.items[7].url).toBe('http://pipe.example/ch7/video.ts') // pipe stripped
  expect(result.items[7].http['user-agent']).toBe('BenchUA')
  expect(result.items[0].url).toBe('http://streams.example/live/ch0/index.m3u8')
  expect(result.items[41].radio).toBe('true')
  expect(result.items[3].http['user-agent']).toBe(
    'Mozilla/5.0 (SyntheticBench) Gecko/2026'
  )
  expect(result.items[25].raw).toContain('# generated comment for channel 25')

  expect(elapsed).toBeLessThan(3000)
})
