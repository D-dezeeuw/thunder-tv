const parser = require('../src/index.js')

// Fork delta: #KODIPROP lines placed BEFORE an #EXTINF apply to the NEXT
// entry (Kodi semantics) and are preserved in that item's `raw`, in file
// order. Upstream drops any '#' line seen outside an open item. IPTVnator
// extracts ClearKey DRM config from these lines (iptvnator#1225).

it('attaches #KODIPROP lines before the first #EXTINF to that item raw', () => {
  const result = parser.parse(
    '#EXTM3U\n' +
      '#KODIPROP:inputstream.adaptive.license_type=clearkey\n' +
      '#KODIPROP:inputstream.adaptive.license_key=kid123:key456\n' +
      '#EXTINF:-1 tvg-id="one",One\n' +
      'http://example.com/one.mpd\n'
  )

  expect(result.items.length).toBe(1)
  expect(result.items[0].url).toBe('http://example.com/one.mpd')
  expect(result.items[0].raw).toBe(
    '#KODIPROP:inputstream.adaptive.license_type=clearkey\r\n' +
      '#KODIPROP:inputstream.adaptive.license_key=kid123:key456\r\n' +
      '#EXTINF:-1 tvg-id="one",One\r\n' +
      'http://example.com/one.mpd'
  )
})

it('applies #KODIPROP lines between items to the following item only', () => {
  const result = parser.parse(
    '#EXTM3U\n' +
      '#EXTINF:-1,Plain\n' +
      'http://example.com/plain.m3u8\n' +
      '#KODIPROP:inputstream.adaptive.license_type=clearkey\n' +
      '#EXTINF:-1,Encrypted\n' +
      'http://example.com/enc.mpd\n'
  )

  expect(result.items.length).toBe(2)
  expect(result.items[0].raw).toBe(
    '#EXTINF:-1,Plain\r\nhttp://example.com/plain.m3u8'
  )
  expect(result.items[1].raw).toBe(
    '#KODIPROP:inputstream.adaptive.license_type=clearkey\r\n' +
      '#EXTINF:-1,Encrypted\r\n' +
      'http://example.com/enc.mpd'
  )
})

it('keeps #KODIPROP lines after #EXTINF in raw as before', () => {
  const result = parser.parse(
    '#EXTM3U\n' +
      '#EXTINF:-1,Encrypted\n' +
      '#KODIPROP:inputstream.adaptive.license_type=clearkey\n' +
      'http://example.com/enc.mpd\n'
  )

  expect(result.items[0].raw).toBe(
    '#EXTINF:-1,Encrypted\r\n' +
      '#KODIPROP:inputstream.adaptive.license_type=clearkey\r\n' +
      'http://example.com/enc.mpd'
  )
})

it('combines #KODIPROP lines before and after #EXTINF in file order', () => {
  const result = parser.parse(
    '#EXTM3U\n' +
      '#KODIPROP:inputstream.adaptive.license_type=clearkey\n' +
      '#EXTINF:-1,Encrypted\n' +
      '#KODIPROP:inputstream.adaptive.license_key=kid123:key456\n' +
      'http://example.com/enc.mpd\n'
  )

  expect(result.items[0].raw).toBe(
    '#KODIPROP:inputstream.adaptive.license_type=clearkey\r\n' +
      '#EXTINF:-1,Encrypted\r\n' +
      '#KODIPROP:inputstream.adaptive.license_key=kid123:key456\r\n' +
      'http://example.com/enc.mpd'
  )
})

it('accepts a case-insensitive #KodiProp prefix', () => {
  const result = parser.parse(
    '#EXTM3U\n' +
      '#KodiProp:inputstream.adaptive.license_type=clearkey\n' +
      '#EXTINF:-1,One\n' +
      'http://example.com/one.mpd\n'
  )

  expect(result.items[0].raw).toContain(
    '#KodiProp:inputstream.adaptive.license_type=clearkey'
  )
})

it('still drops non-KODIPROP comment lines outside an open item', () => {
  const result = parser.parse(
    '#EXTM3U\n' +
      '# random comment\n' +
      '#PLAYLISTV:something\n' +
      '#EXTINF:-1,One\n' +
      'http://example.com/one.m3u8\n'
  )

  expect(result.items[0].raw).toBe(
    '#EXTINF:-1,One\r\nhttp://example.com/one.m3u8'
  )
})

it('silently discards trailing #KODIPROP lines with no following #EXTINF', () => {
  const result = parser.parse(
    '#EXTM3U\n' +
      '#EXTINF:-1,One\n' +
      'http://example.com/one.m3u8\n' +
      '#KODIPROP:inputstream.adaptive.license_type=clearkey\n'
  )

  expect(result.items.length).toBe(1)
  expect(result.items[0].raw).toBe(
    '#EXTINF:-1,One\r\nhttp://example.com/one.m3u8'
  )
})
