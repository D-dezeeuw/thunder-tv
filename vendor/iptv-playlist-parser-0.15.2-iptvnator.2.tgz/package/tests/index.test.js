import parser from '../src'
import path from 'path'
import fs from 'fs'

it('parse playlist', done => {
  import('./__data__/expected/base.js')
    .then(({ default: expected }) => {
      expect(parser.parse(content('tests/__data__/input/base.m3u'))).toEqual(expected)
      done()
    })
    .catch(done)
})

it('could parse playlist with comments', done => {
  import('./__data__/expected/comment.js')
    .then(({ default: expected }) => {
      expect(parser.parse(content('tests/__data__/input/comment.m3u'))).toEqual(expected)
      done()
    })
    .catch(done)
})

it('could parse playlist with #EXTGRP and #EXTVLCOPT tag', done => {
  import('./__data__/expected/vlcopt.js')
    .then(({ default: expected }) => {
      expect(parser.parse(content('tests/__data__/input/vlcopt.m3u'))).toEqual(expected)
      done()
    })
    .catch(done)
})

it('could parse playlist with user agent in attribute', done => {
  import('./__data__/expected/user_agent.js')
    .then(({ default: expected }) => {
      expect(parser.parse(content('tests/__data__/input/user_agent.m3u'))).toEqual(expected)
      done()
    })
    .catch(done)
})

it('could parse playlist with user agent and referer in the url string', done => {
  import('./__data__/expected/pipe.js')
    .then(({ default: expected }) => {
      expect(parser.parse(content('tests/__data__/input/pipe.m3u'))).toEqual(expected)
      done()
    })
    .catch(done)
})

it('could parse playlist with url-tvg in header', done => {
  import('./__data__/expected/url_tvg.js')
    .then(({ default: expected }) => {
      expect(parser.parse(content('tests/__data__/input/url_tvg.m3u'))).toEqual(expected)
      done()
    })
    .catch(done)
})

it('could parse playlist with duplicates', done => {
  import('./__data__/expected/duplicate.js')
    .then(({ default: expected }) => {
      expect(parser.parse(content('tests/__data__/input/duplicate.m3u'))).toEqual(expected)
      done()
    })
    .catch(done)
})

it('can parse playlist with #KODIPROP', done => {
  import('./__data__/expected/kodi.js')
    .then(({ default: expected }) => {
      expect(parser.parse(content('tests/__data__/input/kodi.m3u'))).toEqual(expected)
      done()
    })
    .catch(done)
})

it('accepts URLs with LAN hostnames (no TLD)', done => {
  import('./__data__/expected/lan_host.js')
    .then(({ default: expected }) => {
      expect(parser.parse(content('tests/__data__/input/lan_host.m3u'))).toEqual(expected)
      done()
    })
    .catch(done)
})

it('parses channels with URLs longer than 2084 characters (iptvnator#1189)', () => {
  const result = parser.parse(content('tests/__data__/input/long_url.m3u'))
  expect(result.items.length).toBe(2)
  expect(result.items[0].name).toBe('Beyblade')
  expect(result.items[0].url.length).toBeGreaterThan(2084)
  expect(result.items[0].url.startsWith('https://')).toBe(true)
  expect(result.items[1].name).toBe('TV Cultura')
  expect(result.items[1].url).not.toBe(result.items[0].url)
  expect(result.items[1].url.length).toBeGreaterThan(2084)
})

it('ignores comments and unknown directives between #EXTINF and the URL', () => {
  const result = parser.parse(content('tests/__data__/input/comment_directives.m3u'))
  expect(result.items.length).toBe(2)
  expect(result.items[0].name).toBe('Channel One')
  expect(result.items[0].url).toBe('http://example.com/one.m3u8')
  expect(result.items[0].raw).toContain('# a stray comment between EXTINF and its URL')
  expect(result.items[0].raw).toContain('#EXT-X-SESSION-DATA')
  expect(result.items[1].name).toBe('Channel Two')
  expect(result.items[1].url).toBe('http://example.com/two.m3u8')
})

it('parses the radio attribute value', () => {
  const result = parser.parse(content('tests/__data__/input/radio.m3u'))
  expect(result.items.length).toBe(3)
  expect(result.items[0].radio).toBe('true')
  expect(result.items[1].radio).toBe('yes')
  expect(result.items[2].radio).toBe('')
})

function content(filepath) {
  return fs.readFileSync(path.resolve(filepath), {
    encoding: 'utf8'
  })
}
