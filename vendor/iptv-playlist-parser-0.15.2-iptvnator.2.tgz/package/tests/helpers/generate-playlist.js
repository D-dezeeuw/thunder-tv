// Deterministic synthetic playlist generator shared by the scale test and
// `npm run bench`. Index-based variation, no randomness: the same count
// always produces the same playlist.
const JWT = 'e'.repeat(2100)

function channelBlock(i) {
  const lines = [
    `#EXTINF:-1 tvg-id="ch${i}" tvg-name="Channel ${i}" ` +
      `tvg-logo="https://logos.example/ch${i}.png" ` +
      `group-title="Group ${i % 50}"` +
      (i % 41 === 0 ? ' radio="true"' : '') +
      `,Channel ${i}`
  ]
  if (i % 25 === 0) lines.push(`# generated comment for channel ${i}`)
  if (i % 10 === 3) {
    lines.push(
      '#EXTVLCOPT:http-user-agent=Mozilla/5.0 (SyntheticBench) Gecko/2026'
    )
  }
  if (i % 5 === 1) {
    // Pluto-style long JWT URL (>2084 chars) — iptvnator#1189 territory
    lines.push(
      `https://stitcher.example/v2/hls/channel/ch${i}/master.m3u8?jwt=${JWT}&idx=${i}`
    )
  } else if (i % 10 === 7) {
    lines.push(`http://pipe.example/ch${i}/video.ts|User-Agent=BenchUA&Referer=http://ref.example/${i}`)
  } else {
    lines.push(`http://streams.example/live/ch${i}/index.m3u8`)
  }
  return lines.join('\n')
}

function generatePlaylist(count) {
  const parts = ['#EXTM3U x-tvg-url="https://epg.example/guide.xml"']
  for (let i = 0; i < count; i++) parts.push(channelBlock(i))
  parts.push('')
  return parts.join('\n')
}

module.exports = { generatePlaylist }
