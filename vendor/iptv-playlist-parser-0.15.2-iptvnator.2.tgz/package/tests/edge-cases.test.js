import parser from '../src'

// Edge-case coverage for branches the fixture-based tests do not reach.
// These pin upstream-0.15.2-compatible semantics (verified differentially
// against the reference implementation) so the optimized parse() cannot
// silently drift.

it('throws on content without an #EXTM3U header', () => {
  expect(() => parser.parse('')).toThrow('Playlist is not valid')
  expect(() => parser.parse('#EXTINF:-1,No header\nhttp://x/1.ts')).toThrow(
    'Playlist is not valid'
  )
})

it('parses an #EXTINF line without a comma as an empty name', () => {
  const result = parser.parse('#EXTM3U\n#EXTINF:-1 tvg-id="one"\nhttp://x/1.ts')
  expect(result.items.length).toBe(1)
  expect(result.items[0].name).toBe('')
  expect(result.items[0].tvg.id).toBe('one')
})

it('parses an #EXTINF line carrying every supported attribute', () => {
  const line =
    '#EXTINF:-1 tvg-id="id" tvg-name="nm" tvg-logo="lg" tvg-url="tu" ' +
    'tvg-rec="3" tvg-shift="-1" group-title="grp" referrer="ref" ' +
    'user-agent="ua" catchup="shift" catchup-days="7" catchup-source="cs" ' +
    'timeshift="2" lang="eng" radio="true",Full'
  const result = parser.parse(`#EXTM3U\n${line}\nhttp://x/full.ts`)
  expect(result.items[0]).toMatchObject({
    name: 'Full',
    tvg: { id: 'id', name: 'nm', logo: 'lg', url: 'tu', rec: '3', shift: '-1' },
    group: { title: 'grp' },
    http: { referrer: 'ref', 'user-agent': 'ua' },
    url: 'http://x/full.ts',
    catchup: { type: 'shift', days: '7', source: 'cs' },
    timeshift: '2',
    lang: 'eng',
    radio: 'true'
  })
})

it('takes the first attribute match even when its value is empty', () => {
  // upstream getAttribute returns the first regex match; an empty capture
  // maps to '' and is NOT overridden by a later duplicate
  const result = parser.parse(
    '#EXTM3U\n#EXTINF:-1 tvg-id="" tvg-id="second",Dup\nhttp://x/1.ts'
  )
  expect(result.items[0].tvg.id).toBe('')
})

it('matches attribute names as suffixes like upstream getAttribute', () => {
  // upstream regexes are unanchored: getAttribute('user-agent') also matches
  // http-user-agent="...", first occurrence in line order wins
  const result = parser.parse(
    '#EXTM3U\n#EXTINF:-1 http-user-agent="HU" user-agent="U",Coll\nhttp://x/1.ts'
  )
  expect(result.items[0].http['user-agent']).toBe('HU')
})

it('ignores empty header attribute values', () => {
  const result = parser.parse('#EXTM3U x-tvg-url=""\n#EXTINF:-1,A\nhttp://x/1.ts')
  expect(result.header.attrs).toEqual({})
})

it('keeps the previous group title for a bare #EXTGRP: tag', () => {
  const result = parser.parse(
    '#EXTM3U\n#EXTINF:-1 group-title="Kept",A\n#EXTGRP:\nhttp://x/1.ts'
  )
  expect(result.items[0].group.title).toBe('Kept')
  expect(result.items[0].raw).toContain('#EXTGRP:')
})

it('keeps the item open when a line is only pipe parameters', () => {
  const result = parser.parse(
    '#EXTM3U\n#EXTINF:-1,A\n|User-Agent=UA\nhttp://x/real.ts'
  )
  expect(result.items.length).toBe(1)
  expect(result.items[0].url).toBe('http://x/real.ts')
  expect(result.items[0].raw).toContain('|User-Agent=UA')
})

it('appends consecutive blank and comment lines to raw in order', () => {
  const result = parser.parse(
    '#EXTM3U\n#EXTINF:-1,A\n# note\n\n# second note\nhttp://x/1.ts'
  )
  expect(result.items.length).toBe(1)
  expect(result.items[0].raw).toBe(
    '#EXTINF:-1,A\r\n# note\r\n\r\n# second note\r\nhttp://x/1.ts'
  )
})

it('keeps a trailing #EXTINF without URL, url stays undefined', () => {
  const bare = parser.parse('#EXTM3U\n#EXTINF:-1,Tail')
  expect(bare.items.length).toBe(1)
  expect(bare.items[0].url).toBeUndefined()
  expect(bare.items[0].raw).toBe('#EXTINF:-1,Tail')

  const withComment = parser.parse('#EXTM3U\n#EXTINF:-1,Tail\n# dangling note')
  expect(withComment.items.length).toBe(1)
  expect(withComment.items[0].url).toBeUndefined()
  expect(withComment.items[0].raw).toBe('#EXTINF:-1,Tail\r\n# dangling note')
})

it('parses CRLF playlists without embedding \\r into fields', () => {
  const result = parser.parse(
    '#EXTM3U\r\n#EXTINF:-1 tvg-id="crlf" radio="true",CRLF\r\nhttp://x/1.ts|User-Agent=UA\r\n'
  )
  expect(result.items.length).toBe(1)
  expect(result.items[0].name).toBe('CRLF')
  expect(result.items[0].url).toBe('http://x/1.ts')
  expect(result.items[0].http['user-agent']).toBe('UA')
  expect(result.items[0].radio).toBe('true')
})

it('accepts a UTF-8 BOM before the #EXTM3U header', () => {
  const result = parser.parse('﻿#EXTM3U\n#EXTINF:-1,A\nhttp://x/1.ts')
  expect(result.items.length).toBe(1)
  expect(result.header.raw).toBe('#EXTM3U')
})

it('accepts blank lines and whitespace before the #EXTM3U header', () => {
  const result = parser.parse('\n\n  #EXTM3U\n#EXTINF:-1,A\nhttp://x/1.ts')
  expect(result.items.length).toBe(1)
  // item.line stays the absolute line number in the file
  expect(result.items[0].line).toBe(4)
})

it('accepts a lowercase #extm3u header', () => {
  const result = parser.parse('#extm3u\n#EXTINF:-1,A\nhttp://x/1.ts')
  expect(result.items.length).toBe(1)
})

it('rejects content that is blank lines only', () => {
  expect(() => parser.parse('\n\n  \n')).toThrow('Playlist is not valid')
})

it('accepts a Node Buffer and parses it as UTF-8', () => {
  const result = parser.parse(Buffer.from('#EXTM3U\n#EXTINF:-1,Ä\nhttp://x/1.ts'))
  expect(result.items.length).toBe(1)
  expect(result.items[0].name).toBe('Ä')
})

it('throws a clear TypeError for non-string, non-Buffer input', () => {
  for (const bad of [null, undefined, 42, {}, ['#EXTM3U']]) {
    expect(() => parser.parse(bad)).toThrow(TypeError)
    expect(() => parser.parse(bad)).toThrow(
      /parse\(\) expects an M3U playlist as a string or Buffer/
    )
  }
})

it('never throws or hangs on junk content after a valid header', () => {
  // deterministic pseudo-random junk: printable ASCII lines of varying length
  let junk = '#EXTM3U\n'
  for (let i = 0; i < 2000; i++) {
    junk += String.fromCharCode(33 + ((i * 7) % 90)).repeat(1 + (i % 80)) + '\n'
  }
  const result = parser.parse(junk)
  expect(result.items.length).toBe(0)

  // same junk interleaved with real entries: every EXTINF must survive
  let mixed = '#EXTM3U\n'
  for (let i = 0; i < 500; i++) {
    mixed += `!@junk-${i} $%^&*()\n`
    mixed += `#EXTINF:-1 tvg-id="s${i}",Station ${i}\n`
    mixed += `#garbage directive ${i}\n`
    mixed += `http://x/${i}.ts\n`
  }
  const survived = parser.parse(mixed)
  expect(survived.items.length).toBe(500)
  expect(survived.items.every((item, i) => item.url === `http://x/${i}.ts`)).toBe(true)
})
