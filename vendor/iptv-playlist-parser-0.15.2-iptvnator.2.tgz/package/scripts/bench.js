// Standalone benchmark: `npm run bench` (not part of CI).
// Prints median parse time for 10k and 100k synthetic channels.
const { parse } = require('../src')
const { generatePlaylist } = require('../tests/helpers/generate-playlist')

for (const count of [10000, 100000]) {
  const playlist = generatePlaylist(count)
  parse(playlist) // warmup
  const times = []
  for (let i = 0; i < 7; i++) {
    const t = process.hrtime.bigint()
    parse(playlist)
    times.push(Number(process.hrtime.bigint() - t) / 1e6)
  }
  times.sort((a, b) => a - b)
  console.log(
    `${count} channels: median ${times[3].toFixed(1)} ms ` +
      `(min ${times[0].toFixed(1)}, max ${times[6].toFixed(1)})`
  )
}
